import{a as t}from"../chunks/entry.D9NTSHOa.js";export{t as start};
