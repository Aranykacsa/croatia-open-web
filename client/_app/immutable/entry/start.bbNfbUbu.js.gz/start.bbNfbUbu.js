import{a as t}from"../chunks/entry.Egj1kVpK.js";export{t as start};
