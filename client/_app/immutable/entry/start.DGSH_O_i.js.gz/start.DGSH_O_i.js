import{a as t}from"../chunks/entry.RnEd4175.js";export{t as start};
