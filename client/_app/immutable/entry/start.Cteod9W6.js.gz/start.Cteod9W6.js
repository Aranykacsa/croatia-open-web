import{a as t}from"../chunks/entry.Bop3qSUH.js";export{t as start};
