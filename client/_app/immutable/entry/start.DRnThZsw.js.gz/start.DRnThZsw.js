import{a as t}from"../chunks/entry.Cj7j2E6l.js";export{t as start};
