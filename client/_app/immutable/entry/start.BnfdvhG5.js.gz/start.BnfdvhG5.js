import{a as t}from"../chunks/entry.ktam2ni4.js";export{t as start};
