import{a as t}from"../chunks/entry.9e2wYKyb.js";export{t as start};
