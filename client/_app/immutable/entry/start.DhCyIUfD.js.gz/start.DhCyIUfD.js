import{a as t}from"../chunks/entry.soLQrTUV.js";export{t as start};
